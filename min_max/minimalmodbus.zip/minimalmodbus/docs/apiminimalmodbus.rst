.. _apiminimalmodbus:

API for MinimalModbus
=====================

.. automodule:: minimalmodbus
   :members:
   :undoc-members:
   :show-inheritance:


